# EECS 470 Lab 1

To get started on CAEN, follow the Lab/Project Setup Guide on the
[EECS-470 GitHub home page](https://github.com/EECS-470).

Find the assignment and worksheet for this lab on the
[Course Website](https://www.eecs.umich.edu/courses/eecs470/assignments.html).
